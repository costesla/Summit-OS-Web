import azure.functions as func
import sys
import os
import logging
import json

# Path fix - MUST BE ABSOLUTE to prevent blueprint import failures
app_root = os.path.dirname(os.path.abspath(__file__))
if app_root not in sys.path:
    sys.path.append(app_root)

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="ping", methods=["GET"])
def ping_root(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse("pong from root", status_code=200)

# Robust Blueprint Registration
import importlib
blueprints = [
    "api.pricing",
    "api.ocr",
    "api.bookings",
    "api.tessie",
    "api.reports",
    "api.copilot",
    "api.health"
]

registration_logs = []
for module_path in blueprints:
    try:
        module = importlib.import_module(module_path)
        if hasattr(module, 'bp'):
            app.register_blueprint(module.bp)
            registration_logs.append(f"SUCCESS: {module_path}")
        else:
            registration_logs.append(f"WARNING: {module_path} has no 'bp'")
    except Exception as e:
        registration_logs.append(f"ERROR: {module_path}: {str(e)}")

@app.route(route="diag", methods=["GET"])
def diag(req: func.HttpRequest) -> func.HttpResponse:
    import sys
    import os
    info = {
        "sys.path": sys.path,
        "cwd": os.getcwd(),
        "files": os.listdir('.'),
        "api_files": os.listdir('api') if os.path.exists('api') else "MISSING api",
        "registration_logs": registration_logs
    }
    return func.HttpResponse(json.dumps(info, indent=2), mimetype="application/json")
