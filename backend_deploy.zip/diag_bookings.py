import requests
import json

tenant_id = "1cd94367-e5ad-4827-90a9-cc4c6124a340"
client_id = "a7d212ac-dd2b-4910-a62a-b623a8ac250c"
client_secret = "~7z8Q~nZs9E.XD_LMg1d1eNTgqfs91hOw2TkfdqM"

def get_token():
    url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    data = {
        "client_id": client_id,
        "scope": "https://graph.microsoft.com/.default",
        "client_secret": client_secret,
        "grant_type": "client_credentials"
    }
    resp = requests.post(url, data=data)
    return resp.json().get("access_token")

def list_services():
    token = get_token()
    business_id = "SummitOS@costesla.com"
    url = f"https://graph.microsoft.com/v1.0/solutions/bookingBusinesses/{business_id}/services"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    resp = requests.get(url, headers=headers)
    if resp.ok:
        services = resp.json().get("value", [])
        for s in services:
            print(f"ID: {s.get('id')}, Name: {s.get('displayName')}")
    else:
        print(f"Error: {resp.status_code} - {resp.text}")

if __name__ == "__main__":
    list_services()
