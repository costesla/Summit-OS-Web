import logging
import azure.functions as func
import json
import os
import googlemaps
from services.pricing import PricingEngine

bp = func.Blueprint()

@bp.route(route="quote", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def quote(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Pricing quote requested via Blueprint")
    
    try:
        req_body = req.get_json()
        pickup = req_body.get('pickup', '')
        dropoff = req_body.get('dropoff', '')
        customer_email = req_body.get('email', req_body.get('customerEmail', ''))
        
        gmaps_key = os.environ.get("GOOGLE_MAPS_API_KEY")
        if not gmaps_key:
            raise Exception("Google Maps API Key missing from environment")
            
        gmaps = googlemaps.Client(key=gmaps_key)
        
        # We'll use directions instead of distance_matrix for better waypoint support
        # and more robust geocoding (region bias)
        stops = req_body.get('stops', [])
        
        # Clean up stops
        valid_stops = [s for s in stops if s and s.strip()]
        
        # Use directions API
        directions_res = gmaps.directions(
            origin=pickup,
            destination=dropoff,
            waypoints=valid_stops,
            mode="driving",
            region="us"
        )
        
        if not directions_res:
             logging.warning(f"No directions found for {pickup} -> {dropoff} with {len(valid_stops)} stops")
             raise Exception(f"Unable to find a driving route between these addresses (NOT_FOUND)")
             
        # Extract total distance and duration from all legs
        route = directions_res[0]
        legs = route.get('legs', [])
        
        total_dist_meters = sum(leg['distance']['value'] for leg in legs)
        total_duration_sec = sum(leg['duration']['value'] for leg in legs)
        
        dist_miles = total_dist_meters * 0.000621371
        dur_text = legs[0]['duration']['text'] if len(legs) == 1 else f"{total_duration_sec // 60} mins"
        
        # Get actual addresses from Google
        actual_origin = legs[0]['start_address']
        actual_dest = legs[-1]['end_address']

        # Round Trip Logic
        trip_type = req_body.get('tripType', 'one-way')
        return_stops = req_body.get('returnStops', [])
        valid_return_stops = [s for s in return_stops if s and s.strip()]
        
        total_dist_miles = dist_miles
        total_stops = len(valid_stops)
        
        if trip_type == 'round-trip':
            # Calculate return leg
            return_res = gmaps.directions(
                origin=dropoff,
                destination=pickup,
                waypoints=valid_return_stops,
                mode="driving",
                region="us"
            )
            if return_res:
                return_route = return_res[0]
                return_legs = return_route.get('legs', [])
                return_dist_meters = sum(leg['distance']['value'] for leg in return_legs)
                total_dist_miles += return_dist_meters * 0.000621371
                total_stops += len(valid_return_stops)
                
        # Wait time logic
        layover_hours = float(req_body.get('layoverHours', 0))
        simple_wait_time = req_body.get('simpleWaitTime', False)
        
        # If simple wait time is requested, assume 1 hour as placeholder or handle as needed
        # Actually, if waitTime is True in frontend, simpleWaitTime will be True.
        # Let's use 1 hour if it's a one-way with wait time requested, unless specified otherwise.
        wait_hours = layover_hours
        if trip_type == 'one-way' and simple_wait_time:
            wait_hours = max(wait_hours, 1.0)

        pricing = PricingEngine()
        quote_data = pricing.calculate_trip_price(
            distance_miles=total_dist_miles,
            stops_count=total_stops,
            wait_time_hours=wait_hours,
            customer_email=customer_email
        )
        
        quote_data["debug"] = {
            "duration": dur_text, 
            "miles": f"{dist_miles:.1f}",
            "origin": actual_origin,
            "destination": actual_dest
        }
        quote_data["time"] = total_duration_sec // 60
            
        return func.HttpResponse(
            json.dumps({"success": True, "quote": quote_data}),
            status_code=200,
            mimetype="application/json"
        )
    except Exception as e:
        error_msg = str(e)
        logging.error(f"Pricing Error: {error_msg}")
        
        # If it's a known routing/external error, return 200 with success=False
        # This prevents the frontend from showing a 500 toast while typing
        if "Google Maps" in error_msg or "route" in error_msg.lower():
            return func.HttpResponse(
                json.dumps({"success": False, "error": error_msg}),
                status_code=200,
                mimetype="application/json"
            )
            
        return func.HttpResponse(
            json.dumps({"success": False, "error": "Internal Pricing Engine Error"}),
            status_code=500,
            mimetype="application/json"
        )
