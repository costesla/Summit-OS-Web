import os
import sys
import logging
from lib.ocr import OCRClient
from lib.tessie import TessieClient

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def test_pipeline(image_path_or_url):
    logging.info(f"--- Starting Local Test for: {image_path_or_url} ---")
    
    # 1. OCR
    ocr = OCRClient()
    if not ocr.client:
        logging.warning("⚠️  OCR Client not initialized (Missing Env Vars?). Skipping actual OCR.")
        # Mock text for testing parsing logic if OCR fails
        raw_text = """
        Picking up Ethan
        Comfort
        Total $24.52
        Your earnings $14.12
        Tip $4.00
        12.5 mi
        24 min
        """
        logging.info("Using MOCK text for logic verification.")
    else:
        # Check if local file or URL
        if os.path.exists(image_path_or_url):
            # For local files, we'd need to upload to blob or use 'read_in_stream'
            # But our OCRClient currently expects a URL (Read API).
            # For this test, we might fail unless we change OCRClient to support streams.
            logging.error("OCRClient currently expects a URL. Please provide a public URL or enable stream support.")
            return
        else:
            raw_text = ocr.extract_text(image_path_or_url)

    if not raw_text:
        logging.error("❌ No text extracted.")
        return

    # 2. Parse
    trip_data = ocr.parse_ubertrip(raw_text)
    logging.info("✅ Parsed Data:")
    for k, v in trip_data.items():
        logging.info(f"   {k}: {v}")

    # 3. Tessie
    tessie = TessieClient()
    if not tessie.api_key:
        logging.warning("⚠️  Tessie API Key missing. Skipping matching.")
    else:
        # Mock a timestamp for "now" or extraction
        import time
        fake_timestamp = time.time() 
        vin = os.environ.get("TESSIE_VIN")
        if vin:
            drive = tessie.match_drive_to_trip(vin, fake_timestamp)
            if drive:
                logging.info(f"✅ Match Found: Drive ID {drive.get('id')}")
            else:
                logging.info("result: No matching drive found (Expected if using random timestamp).")
        else:
            logging.warning("⚠️  TESSIE_VIN not set.")

if __name__ == "__main__":
    # Load env vars if needed (dotenv)
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except:
        pass

    target = "https://example.com/sample_receipt.jpg" 
    if len(sys.argv) > 1:
        target = sys.argv[1]
    
    test_pipeline(target)
