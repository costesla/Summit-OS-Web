import os
import logging
import pyodbc

class DatabaseClient:
    def __init__(self):
        self.connection_string = os.environ.get("SQL_CONNECTION_STRING")

    def get_connection(self):
        if not self.connection_string:
            logging.error("SQL_CONNECTION_STRING not set.")
            return None
        try:
            return pyodbc.connect(self.connection_string)
        except Exception as e:
            logging.error(f"Failed to connect to SQL: {e}")
            return None

    def save_trip(self, trip_data):
        logging.info(f"Saving to Knowledge Vault: {trip_data.get('block_name')} | {trip_data.get('trip_id')}")
        
        conn = self.get_connection()
        if not conn:
            return

        cursor = conn.cursor()
        
        # Schema: Summit_Trips (
        #   BlockName, TripID, Classification, SourceURL, 
        #   Rider, RiderPayment, DriverTotal, Tip, UberCut, 
        #   Distance, Duration, ServiceType, Airport, Result,
        #   TessieDriveID, TessieDistance, EfficiencyGap, EfficiencyDetail
        #   RecallTag, Status
        # )
        
        # Generate Recall Tag
        recall_tag = f"{trip_data.get('classification')} - {trip_data.get('block_name')} - {trip_data.get('trip_id')}"
        if trip_data.get('rider'):
            recall_tag += f" - {trip_data.get('rider')}"

        query = """
        MERGE INTO Summit_Trips AS target
        USING (SELECT ? AS SourceURL) AS source
        ON (target.SourceURL = source.SourceURL)
        WHEN MATCHED THEN
            UPDATE SET 
                BlockName = ?, TripID = ?, Classification = ?,
                Rider = ?, RiderPayment = ?, DriverTotal = ?, Tip = ?, UberCut = ?,
                Distance = ?, Duration = ?, ServiceType = ?, Airport = ?, Result = ?,
                TessieDriveID = ?, TessieDistance = ?, EfficiencyGap = ?,
                RecallTag = ?, Status = 'Verified', LastUpdated = GETDATE()
        WHEN NOT MATCHED THEN
            INSERT (
                SourceURL, BlockName, TripID, Classification,
                Rider, RiderPayment, DriverTotal, Tip, UberCut,
                Distance, Duration, ServiceType, Airport, Result,
                TessieDriveID, TessieDistance, EfficiencyGap,
                RecallTag, Status, CreatedAt, LastUpdated
            )
            VALUES (
                ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?,
                ?, 'Verified', GETDATE(), GETDATE()
            );
        """
        
        params = (
            trip_data.get('source_url'), 
            # Update Params
            trip_data.get('block_name'), trip_data.get('trip_id'), trip_data.get('classification'),
            trip_data.get('rider'), trip_data.get('rider_payment', 0), trip_data.get('driver_total', 0), 
            trip_data.get('tip', 0), trip_data.get('uber_cut', 0),
            trip_data.get('distance_miles', 0), trip_data.get('duration_minutes', 0), 
            trip_data.get('service_type'), trip_data.get('airport', False), trip_data.get('result'),
            trip_data.get('tessie_drive_id'), trip_data.get('tessie_distance'), trip_data.get('efficiency_gap'),
            recall_tag,
            # Insert Params (re-mapping)
            trip_data.get('source_url'),
            trip_data.get('block_name'), trip_data.get('trip_id'), trip_data.get('classification'),
            trip_data.get('rider'), trip_data.get('rider_payment', 0), trip_data.get('driver_total', 0), 
            trip_data.get('tip', 0), trip_data.get('uber_cut', 0),
            trip_data.get('distance_miles', 0), trip_data.get('duration_minutes', 0), 
            trip_data.get('service_type'), trip_data.get('airport', False), trip_data.get('result'),
            trip_data.get('tessie_drive_id'), trip_data.get('tessie_distance'), trip_data.get('efficiency_gap'),
            recall_tag
        )

        try:
            cursor.execute(query, params)
            conn.commit()
            logging.info("Record saved/updated in Summit_Trips.")
        except Exception as e:
            logging.error(f"Error executing SQL: {e}")
        finally:
            conn.close()

