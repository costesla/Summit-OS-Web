import os
import logging
import requests
from datetime import datetime

class TessieClient:
    def __init__(self):
        self.api_key = os.environ.get("TESSIE_API_KEY")
        self.base_url = "https://api.tessie.com"
        
        if not self.api_key:
            logging.warning("Tessie API key not found. Telemetry will not function.")

    def get_latest_drive(self, vin):
        """
        Fetches the most recent drive for the specified VIN.
        """
        if not self.api_key:
            return None

        logging.info(f"Fetching latest drive for VIN: {vin}")
        try:
            url = f"{self.base_url}/{vin}/drives"
            headers = {"Authorization": f"Bearer {self.api_key}"}
            # Limit to 1 to get the latest
            params = {"limit": 1} 
            
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            if data and 'results' in data and len(data['results']) > 0:
                return data['results'][0]
            return None
            
        except Exception as e:
            logging.error(f"Error fetching Tessie data: {str(e)}")
            return None

    def match_drive_to_trip(self, vin, trip_end_timestamp, is_private=False):
        """
        Matches a trip's end timestamp (from file creation) to a Tessie drive.
        Tolerance: 20 mins for Uber, 120 mins for Private.
        """
        if not self.api_key:
            return None
            
        allowed_gap_minutes = 120 if is_private else 20
        trip_end_dt = datetime.fromtimestamp(trip_end_timestamp)

        # 1. Fetch drives for the day of the trip (plus/minus buffer)
        # We search a broad range to be safe
        ts_start = int(trip_end_timestamp - (3600 * 4)) # 4 hours before
        ts_end = int(trip_end_timestamp + (3600 * 4))   # 4 hours after
        
        try:
            url = f"{self.base_url}/{vin}/drives"
            headers = {"Authorization": f"Bearer {self.api_key}"}
            params = {
                "from": ts_start,
                "to": ts_end,
                "limit": 10 # Should be enough for a 8 hour window
            }
            
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            drives = data.get('results', [])
            
            logging.info(f"Searching {len(drives)} drives for match near {trip_end_dt}")

            for drive in drives:
                # Tessie ending_time is usually Unix timestamp
                drive_end_ts = drive.get('ending_time')
                if not drive_end_ts:
                    continue
                    
                diff_minutes = abs((drive_end_ts - trip_end_timestamp) / 60)
                
                if diff_minutes < allowed_gap_minutes:
                    logging.info(f"Drive Match Found! Diff: {diff_minutes:.2f} min (Window: {allowed_gap_minutes})")
                    return drive
            
            logging.info("No matching drive found.")
            return None

        except Exception as e:
            logging.error(f"Error matching Tessie drive: {str(e)}")
            return None
