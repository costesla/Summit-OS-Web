import os
import logging
import time
import re
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from azure.cognitiveservices.vision.computervision.models import OperationStatusCodes
from msrest.authentication import CognitiveServicesCredentials

class OCRClient:
    def __init__(self):
        self.endpoint = os.environ.get("AZURE_VISION_ENDPOINT")
        self.key = os.environ.get("AZURE_VISION_KEY")
        
        if not self.endpoint or not self.key:
            logging.warning("Azure Vision credentials not found. OCR will not function.")
            self.client = None
        else:
            self.client = ComputerVisionClient(self.endpoint, CognitiveServicesCredentials(self.key))

    def extract_text(self, image_url):
        """
        Extracts text from an image URL using Azure Computer Vision (Read API).
        """
        if not self.client:
            logging.error("OCR Client not initialized.")
            return None

        logging.info(f"Starting OCR extraction for: {image_url}")
        try:
            # Call the Read API
            read_response = self.client.read(image_url, raw=True)
            read_operation_location = read_response.headers["Operation-Location"]
            operation_id = read_operation_location.split("/")[-1]

            # Wait for the operation to complete
            while True:
                read_result = self.client.get_read_result(operation_id)
                if read_result.status not in ['notStarted', 'running']:
                    break
                time.sleep(1)

            # Collect results
            text_lines = []
            if read_result.status == OperationStatusCodes.succeeded:
                for text_result in read_result.analyze_result.read_results:
                    for line in text_result.lines:
                        text_lines.append(line.text)
                
                full_text = "\n".join(text_lines)
                logging.info("OCR Extraction successful.")
                return full_text
            else:
                logging.error(f"OCR failed with status: {read_result.status}")
                return None
                
        except Exception as e:
            logging.error(f"Error during OCR extraction: {str(e)}")
            return None

    def parse_ubertrip(self, text):
        """
        Parses raw text from an Uber receipt to extract key details.
        Ported from SummitOS_Stage5b_Intelligence.ps1
        """
        data = {
            "rider": "Unknown",
            "rider_payment": 0.0,
            "driver_total": 0.0,
            "tip": 0.0,
            "uber_cut": 0.0,
            "distance_miles": 0.0,
            "duration_minutes": 0.0,
            "service_type": None,
            "airport": False,
            "result": "Loss"
        }
        
        if not text:
            return data

        # 1. Rider Name
        # "Picking up Ethan"
        match = re.search(r"Picking up (.+)", text)
        if match:
            data["rider"] = match.group(1).strip()
        
        # 2. Financials
        # Rider Payment: "Rider payment $15.78" or "Price $15.78"
        # Note: Python regex needs escaped $ for literal dollar sign if it's not end of line anchor.
        # But in raw strings, we just look for patterns.
        match = re.search(r"(?:Rider payment|Price|Total)\s*[\$]?([0-9]+\.[0-9]{2})", text, re.IGNORECASE)
        if match:
            data["rider_payment"] = float(match.group(1))

        # Driver Earnings: "Your earnings $7.03" or "You earned $7.03"
        match = re.search(r"(?:Your earnings|You earned)\s*[\$]?([0-9]+\.[0-9]{2})", text, re.IGNORECASE)
        if match:
            data["driver_total"] = float(match.group(1))

        # Tip: "Tip $3.00"
        match = re.search(r"Tip\s*[\$]?([0-9]+\.[0-9]{2})", text, re.IGNORECASE)
        if match:
            data["tip"] = float(match.group(1))
            
        # Private Payment override (Venmo style "+ $15.00")
        match = re.search(r"\+\s?\$?([0-9]+\.[0-9]{2})", text)
        if match and "Venmo" in text: # Simple check for Venmo context
            data["driver_total"] = float(match.group(1))
            data["rider_payment"] = data["driver_total"] # Private trip assumption

        # 3. Stats
        # Distance: "12.5 mi"
        match = re.search(r"([0-9.]+)\s*mi", text, re.IGNORECASE)
        if match:
            data["distance_miles"] = float(match.group(1))

        # Duration: "24 min"
        match = re.search(r"([0-9]+)\s*min", text, re.IGNORECASE)
        if match:
            data["duration_minutes"] = int(match.group(1))

        # 4. Service Type
        if re.search(r"(Comfort|Black|XL|Pet|Green)", text, re.IGNORECASE):
            match = re.search(r"(Comfort|Black|XL|Pet|Green)", text, re.IGNORECASE)
            data["service_type"] = match.group(1)
        if "Exclusive" in text:
            data["service_type"] = (data["service_type"] or "") + " Exclusive"

        # 5. Logic Checks
        if re.search(r"(Airport|DEN|DIA|MCO)", text, re.IGNORECASE):
            data["airport"] = True

        # Calculations
        data["uber_cut"] = data["rider_payment"] - data["driver_total"]
        
        # Win/Loss Logic (Driver check > 50%)
        if data["rider_payment"] > 0:
            if (data["driver_total"] / data["rider_payment"]) >= 0.5:
                data["result"] = "Win"
        elif data["driver_total"] > 0:
            data["result"] = "Win" # Optimistic

        return data

    def classify_image(self, text):
        """
        Classifies the image text into a Summit Sync category:
        - Uber_Core
        - Expense
        - Aviation_Context
        - Environmental_Context
        """
        if not text:
            return "Unknown"
        
        text_lower = text.lower()

        # 1. Aviation
        if "flightradar24" in text_lower or re.search(r"flight\s+path", text_lower):
            return "Aviation_Context"

        # 2. Environmental
        if "weatherwise" in text_lower or re.search(r"radar\s+image", text_lower):
            return "Environmental_Context"

        # 3. Expense (Business Context)
        expense_keywords = [
            "starbucks", "mcdonald", "tacobell", "shell", "chevron", 
            "circle k", "7-eleven", "costco gas", "fuel", "gasoline"
        ]
        if any(keyword in text_lower for keyword in expense_keywords):
            return "Expense"

        # 4. Uber Core
        uber_keywords = ["uber", "trip detail", "rider payment", "your earnings", "picking up"]
        if any(keyword in text_lower for keyword in uber_keywords):
            return "Uber_Core"

        return "Unknown"
