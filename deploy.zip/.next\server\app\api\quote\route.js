var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/quote/route.js")
R.c("server/chunks/[root-of-the-server]__64cd252e._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_quote_route_actions_9b311e90.js")
R.m(35603)
module.exports=R.m(35603).exports
