module.exports=[31339,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_test_page_actions_0477bf5a.js.map