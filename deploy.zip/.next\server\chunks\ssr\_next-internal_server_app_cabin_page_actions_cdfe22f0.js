module.exports=[1300,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cabin_page_actions_cdfe22f0.js.map