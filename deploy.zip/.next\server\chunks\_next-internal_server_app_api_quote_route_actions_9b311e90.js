module.exports=[9615,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_quote_route_actions_9b311e90.js.map