module.exports=[34017,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_book_page_actions_fd0dd983.js.map