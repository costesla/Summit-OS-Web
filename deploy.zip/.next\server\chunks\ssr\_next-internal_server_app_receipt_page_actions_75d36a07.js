module.exports=[97512,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_receipt_page_actions_75d36a07.js.map