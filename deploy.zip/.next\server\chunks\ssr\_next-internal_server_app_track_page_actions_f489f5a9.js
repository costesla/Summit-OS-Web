module.exports=[98421,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_track_page_actions_f489f5a9.js.map