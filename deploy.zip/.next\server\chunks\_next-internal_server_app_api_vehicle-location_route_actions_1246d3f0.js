module.exports=[93280,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_vehicle-location_route_actions_1246d3f0.js.map